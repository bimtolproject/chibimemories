from flask import Flask, request, jsonify
from flask_cors import CORS
import openai

app = Flask(__name__)
CORS(app)

openai.api_key = "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"

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message", "")
    
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "system", "content": "Kamu adalah chatbot asisten pacar yang romantis dan perhatian."},
                  {"role": "user", "content": user_message}]
    )
    
    bot_reply = response["choices"][0]["message"]["content"]
    return jsonify({"reply": bot_reply})

if __name__ == "__main__":
    app.run(debug=True)